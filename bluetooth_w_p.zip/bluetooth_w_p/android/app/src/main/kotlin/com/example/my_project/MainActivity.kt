package com.mycompany.bluetoothwp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/instant_timer.dart';
import '/widgets/empty_list/empty_list_widget.dart';
import '/widgets/strength_indicator/strength_indicator_widget.dart';
import '/custom_code/actions/index.dart' as actions;
import '/flutter_flow/custom_functions.dart' as functions;
import 'device_widget.dart' show DeviceWidget;
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class DeviceModel extends FlutterFlowModel<DeviceWidget> {
  ///  Local state fields for this page.

  int? currentRssi;

  String receivedValue = '';

  List<ServiceStruct> deviceServices = [];
  void addToDeviceServices(ServiceStruct item) => deviceServices.add(item);
  void removeFromDeviceServices(ServiceStruct item) =>
      deviceServices.remove(item);
  void removeAtIndexFromDeviceServices(int index) =>
      deviceServices.removeAt(index);
  void insertAtIndexInDeviceServices(int index, ServiceStruct item) =>
      deviceServices.insert(index, item);
  void updateDeviceServicesAtIndex(
          int index, Function(ServiceStruct) updateFn) =>
      deviceServices[index] = updateFn(deviceServices[index]);

  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  // Stores action output result for [Custom Action - getDeviceServices] action in Device widget.
  List<ServiceStruct>? servicesInDevice;
  InstantTimer? rssiUpdateTimer;
  // Stores action output result for [Custom Action - getRssi] action in Device widget.
  int? updatedRssi;
  // State field(s) for Switch widget.
  bool? switchValue;
  // Stores action output result for [Custom Action - getDeviceServices] action in ScannedDevicesList widget.
  List<ServiceStruct>? servicesFromDevice;
  // Model for StrengthIndicator component.
  late StrengthIndicatorModel strengthIndicatorModel;

  /// Initialization and disposal methods.

  void initState(BuildContext context) {
    strengthIndicatorModel =
        createModel(context, () => StrengthIndicatorModel());
  }

  void dispose() {
    unfocusNode.dispose();
    rssiUpdateTimer?.cancel();
    strengthIndicatorModel.dispose();
  }

  /// Action blocks are added here.

  /// Additional helper methods are added here.
}
